export PKG_DIR="python"

rm -rf ${PKG_DIR} && mkdir -p ${PKG_DIR}

docker run --rm -v $(pwd):/foo -w /foo public.ecr.aws/sam/build-python3.13 \
    pip install -r requirements.txt -t ${PKG_DIR}